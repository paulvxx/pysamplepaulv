
#left = False
#right = True

def addchar(st, ch, side=True):
    if (side):
        return st + ch
    else:
        return ch + st
    
